import { getQuadraticControlPoints } from "./SmoothStrategy.js"

export class CanvasRenderer {
  constructor(ctx, dpr = 1, options = {}) {
    this.ctx = ctx
    this.dpr = dpr
    this.minPointsForCurve = 3
    this.lowFPS = options.lowFPS ?? false
    this.smoothSteps = options.smoothSteps ?? 4
  }

  clearCanvas(width, height) {
    this.ctx.clearRect(0, 0, width / this.dpr, height / this.dpr)
  }

  renderStrokes(strokes) {
    for (const stroke of strokes) {
      this.renderStroke(stroke)
    }
  }

  renderStroke(stroke) {
    const points = stroke.points
    const pressures = stroke.pressures
    if (points.length < this.minPointsForCurve) return

    this.ctx.save()
    this.ctx.lineCap = "round"
    this.ctx.lineJoin = "round"
    this.ctx.globalCompositeOperation =
      stroke.tool === "eraser" ? "destination-out" : "source-over"
    this.ctx.strokeStyle = stroke.color

    this.ctx.beginPath()
    this.ctx.moveTo(points[0].x, points[0].y)

    for (let i = 1; i < points.length - 1; i++) {
      const p0 = points[i - 1]
      const p1 = points[i]
      const p2 = points[i + 1]

      const cp = getQuadraticControlPoints(p0, p1, p2)
      this.ctx.quadraticCurveTo(cp.cx, cp.cy, p1.x, p1.y)

      const width = stroke.baseSize * (0.5 + (pressures[i] || 0.5))
      this.ctx.lineWidth = width
    }

    this.ctx.stroke()
    this.ctx.restore()
  }
}
